package com.p1.JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PETSSAApplication {

	public static void main(String[] args) {
		SpringApplication.run(PETSSAApplication.class, args);
	}

}	
