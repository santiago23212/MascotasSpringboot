package com.p1.JPA.respositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import com.p1.JPA.modelos.Medicamento;

public interface MedicamentoRepositorio extends JpaRepository<Medicamento,Integer>{

}
